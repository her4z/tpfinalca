history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cd etgc
ls
pwd
cd ..
ls
cd /etc
ls
cat hosts
cat hostname 
vim hostname
logout
cat /etc/hostname 
hostnamectl set-hostname TPServer
vim /etc/hosts
logout
ls
cd Material_Adicional_TPVMCA/
ls
apt update
apt install apache2 php libapache2-mod-php
systemctl status apache2
ls
ls
cat /var/www/
cat /var/www/html/index.html 
ls /var/www/html/
ls /var/www
ls /var/www/html/
pwd
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html && cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html
cat /var/www/html/
ls /var/www/html/
rm /var/www/html/index.html 
systemctl restar apache2
systemctl restart apache2
systemctl status apache2
ls
cat index.php 
user www-data
cd /var/www/html/
ls -la
sudo chown -R www-data:www-data /var/www/html/
sudo chmod -R 755 /var/www/html/
ls
ls -la
systemctl restart apache2
vim index.php 
vim index.php 
cat index.php 
apt install mariadb-server
systemctl status mariadb
cd /root/
ls
cd Material_Adicional_TPVMCA/
ls
cat db.sql 
ls
mysql
mysql < db.sql 
mysql
mysql
mariadb
mariadb < db.sql 
mariadb
mariadb < db.sql 
mysql < db.sql 
mariadb
mariadb
pwd
user list
man user
user --help
users
users
cd ..
ls
cd ..
ls
cd home/
ls
cd ..
ls
cd root/
ls
cd Material_Adicional_TPVMCA/
su lcars
mariadb
systemctl restart apache2
vim /var/www/html/index.php 
apt install php-mysql
systemctl restar apache2
systemctl restart apache2
mysql
mariadb ingenieria < db.sql 
mariadb
mariadb < db.sql 
mariadb
mariadb < db.sql 
cd Material_Adicional_TPVMCA/
ls
mariadb < db.sql 
mariadb
mariadb < db.sql 
ip a
clear
ip -4 addr show
ip route | grep default
ip link show
ip -4 addr show
vim /etc/network/interfaces
vim /etc/network/interfaces
vim /etc/network/interfaces
systemctl restart networking
ls
cat .ssh/authorized_keys 
ls
cat Material_Adicional_TPVMCA/clave_publica.pub 
cat /root/Material_Adicional_TPVMCA/clave_privada.txt 
vim /root/Material_Adicional_TPVMCA/clave_privada.txt 
apt install virtualbox-guest-x11 virtualbox-guest-utils
apt update
apt install virtualbox-guest-x11 virtualbox-guest-utils
vim /root/Material_Adicional_TPVMCA/clave_privada.txt 
ls
cd Material_Adicional_TPVMCA/
ls
python3 -m http.server 8000
ip'a
ip a
python3 -m http.server 8000
ip a
ip route
ping 192.168.1.1
ping www.google.com
ping 192.168.1.11
reboot
fdisk list
fdisk 
fdisk --help
fdisk -l
lsblk
fdisk /dev/sdc
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk
partprobe /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir
ls
cd ..
ls
mount /dev/sdc1 /www_dir/
mouncd backup_dir/
cd backup_dir/
ls
cd ..
ls
cd www_dir/
ls
cd ..
ls
mount /dev/sdc2 /backup_dir/
df -h /www_dir /backup_dir
man df
df www_dir/
vim /etc/apache2/sites-available/000-default.conf 
apache2ctl configtest
systemctl restart apache2
ip a
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
systemctl restart apache2
ls\
ls
ls -la
ls
chown -R www-data:www-data /www_dir/ chmod -R 755 /www_dir/
chown -R www-data:www-data /www_dir/
chmod -R 755 /www_dir/
systemctl restar apache2
systemctl restart apache2
curl -s http://localhost/ | head -20
tail -20 /var/log/apache2/error.log
vim /etc/apache2/sites-enabled/000-default.conf 
systemctl restart apache2
tail -20 /var/log/apache2/error.log
vim /etc/apache2/sites-enabled/000-default.conf 
clear
blkid /dev/sdc1
cat /etc/fstab 
cp /etc/fstab /etc/fstab.bak
cat /etc/fstab
cat /etc/fstab.bak 
vim /etc/fstab
blkid /dev/sd1
blkid /dev/sdc1
vim /etc/fstab
blkid /dev/sdc2
vim /etc/fstab
ls
umount /www_dir  /backup_dir 
mount -a
systetmctl daemon-reload
ls
df -h /www_dir /backup_dir/
cd www_dir/
ls
cd ..
ls
cat /proc/partitions 
cat /proc/partitions > /opt/particion
cat opt/particion 
clear
# Discos y montajes
lsblk
df -h | grep -E 'www_dir|backup_dir'
# Archivos web
ls -la /www_dir/
# Apache
systemctl is-active apache2
curl -s -o /dev/null -w "%{http_code}\n" http://localhost/
# fstab
grep -E 'www_dir|backup_dir' /etc/fstab
# archivo particion
cat /opt/particion
clear
lsblk
df -h | grep -E 'www_dir|backup_dir'
ls -la /www_dir/
systemctl is-active apache2
curl -s -o /dev/null -w "%{http_code}\n" http://localhost/
grep -E 'www_dir|backup_dir' /etc/fstab
reboot
